# Petey Addon (v0.10.8)

Decompiled full source code archive for Petey Addon (v0.10.8) Fabric mod for Minecraft 1.21.1.

## About
Clean, unmodified source code and assets extracted directly from `petey-addon-0.10.8.jar`. Includes all modules, Mixins, UI components, sound effects, textures, and descriptors.

- **Target Game Version**: Minecraft 1.21.1
- **Mod Loader**: Fabric
- **Language**: Java 21

## Project Structure
- `com/petey/addon/` — Complete Java source code for all modules, utilities, and client features.
- `com/petey/addon/mixin/` — Fabric mixin implementations.
- `assets/petey-addon/` — Audio (`.ogg`) and texture (`.png`) assets.
- `fabric.mod.json` — Fabric mod configuration manifest.
- `petey-addon.mixins.json` — Mixin registration descriptors.

## Notice & Disclaimers
This repository is provided for transparency, security auditing, and educational analysis. All original rights and trademarks belong to their respective creators.
